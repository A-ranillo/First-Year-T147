alert('Everything is Awesome');

let firstName = prompt('Please Enter Your firstname?');
let lastName = prompt('Please Enter Your lastName?');
confirm('Press OK to continue'); 

const age = prompt('Please Enter Your Age?')

if (age <= 34){
    document.write('My first name is: '+firstName+ "<br>");
    document.write('My last name is: '+lastName+ "<br>");
    document.write('My age is: less than or equal to 34'+ "<br>");
    console.log('My first name is: '+firstName+ "<br>");
    console.log('My last name is: '+lastName+ "<br>");
    console.log('My age is: less than or equal to 34'+ "<br>");
}
else
{
    document.write('My age is: more than 34'+ "<br>");
    console.log('My age is: more than 34'+ "<br>");
}


num1 = 7;
num2 = 8;
num3 = 9;

